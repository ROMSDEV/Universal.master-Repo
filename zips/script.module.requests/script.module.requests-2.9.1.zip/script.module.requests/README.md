script.module.requests
======================

Python requests library packed for KODI.

See https://github.com/kennethreitz/requests
